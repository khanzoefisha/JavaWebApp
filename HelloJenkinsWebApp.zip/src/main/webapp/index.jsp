<html>
  <body>
    <h1>Welcome to Jenkins-Tomcat Demo</h1>
    <a href="hello">Click here to see HelloServlet</a>
  </body>
</html>